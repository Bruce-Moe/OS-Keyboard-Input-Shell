#ifndef _crt_h_
#define _crt_h_

struct CRT {
    static void init();
    static void fini();
};

#endif
