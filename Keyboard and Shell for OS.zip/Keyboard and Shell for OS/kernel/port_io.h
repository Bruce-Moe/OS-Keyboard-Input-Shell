extern "C" unsigned char read_port (int port);
extern "C" void write_port (int port, unsigned char val);
extern "C" void kb_init(void);