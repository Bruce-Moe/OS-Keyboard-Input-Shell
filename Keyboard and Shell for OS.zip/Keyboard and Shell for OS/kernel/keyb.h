extern "C" void kb_init(void);
extern "C" void keyboard_handler(void);