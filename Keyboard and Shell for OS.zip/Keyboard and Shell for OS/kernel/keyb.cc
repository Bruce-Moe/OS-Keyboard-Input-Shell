#include "port_io.h"
#include "keyboard_map.h"
#include "machine.h"
#include "keyb.h"
#include "debug.h"

void kb_init(void) {
    /* Assumption: We have PS/2 keyboard device already in a proper state.
     * We simply enable the keyboard interupt */

    /* Get current master PIC interrupt mask */
    unsigned char curmask_master = read_port (0x21);

    /* Enable only IRQ1 (keyboard) on master pic by clearing 1st bit. 
     * 0 = enabled; 1 = disabled */
    write_port(0x21, curmask_master & 0xFD);
}

/* Maintain a global location for the current video memory to write to */
static int current_loc = 0;
/* Const ref to start of video memory */
static char *const vidptr = (char*)0xb8000;

void keyboard_handler(void) {
    signed char keycode;

    keycode = read_port(0x60);
    /* Only print characters that have a non-zero mapping */
    if(keycode >= 0 && keyboard_map[keycode]) {
        vidptr[current_loc++] = keyboard_map[keycode];
        /* Attribute 0x07 is white on black characters */
            vidptr[current_loc++] = 0x07;
    }

    /* Send End of Interrupt (EOI) to master PIC */
    write_port(0x20, 0x20);
}