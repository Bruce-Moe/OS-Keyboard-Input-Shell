#ifndef _KERNEL_H_
#define _KERNEL_H_

void kernelMain(void);

#endif
