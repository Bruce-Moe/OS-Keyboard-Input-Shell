#ifndef _KEYBOARD_MAP_H_
#define _KEYBOARD_MAP_H_

extern unsigned char keyboard_map[128];

#endif